"""
Inventory-related data models.

This module defines the core data structures for the inventory management
functionality in the Inventa project. It introduces an ``InventoryItem``
model that captures the essential attributes of stock keeping units (SKUs)
including their name, category, quantity on hand, storage location and
timestamps for creation and last update. It also records the user who
created or last modified an item to support audit trails and better
accountability. As part of phase 1 of the project, this model lays the
foundation for basic inventory CRUD operations.

The model has been designed with extendability in mind: additional fields
can be added (e.g., unit price, supplier information, barcodes) without
changing the fundamental schema. The ``Meta`` class sets an ordering by
name to make query results predictable.
"""

from django.db import models
from users.models import User
from products.models import ItemCategory


class InventoryItem(models.Model):
    """Represents a tangible item in the inventory.

    Fields
    ------
    name: str
        Human‑friendly name of the item. This is used throughout the UI.
    category: ItemCategory
        ForeignKey linking the item to its classification.
    quantity: int
        The number of units currently in stock. Negative values are not
        permitted.
    location: str
        A textual representation of where the item is stored (e.g. rack or
        warehouse code). This can be expanded into a separate model if
        geographic locations need to be normalised later.
    created_at: datetime
        Timestamp when the record was first created. Set automatically.
    updated_at: datetime
        Timestamp when the record was last modified. Updated on each save.
    created_by: User
        Reference to the user who created this item. Optional; if the
        creating user is deleted, the value is set to NULL.
    updated_by: User
        Reference to the user who most recently modified this item. Optional;
        if the user is deleted, this value is set to NULL.
    """

    name = models.CharField(max_length=150)
    category = models.ForeignKey(
        ItemCategory, on_delete=models.PROTECT, related_name="inventory_items"
    )
    quantity = models.PositiveIntegerField(default=0)
    location = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="inventory_items_created",
    )
    updated_by = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="inventory_items_updated",
    )

    class Meta:
        ordering = ["name"]
        verbose_name = "Inventory Item"
        verbose_name_plural = "Inventory Items"

    def __str__(self) -> str:
        return f"{self.name} (qty: {self.quantity})"
