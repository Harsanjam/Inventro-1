from django.apps import AppConfig


class InventoryConfig(AppConfig):
    """
    Configuration class for the inventory app. Django uses this class to
    register the application and locate its resources. When Inventa is
    deployed, this configuration enables Django to discover models,
    templates, and other app-specific files. The default_auto_field is set
    globally in the project settings, so there is no need to override it
    here.
    """
    default_auto_field = "django.db.models.BigAutoField"
    name = "inventory"
