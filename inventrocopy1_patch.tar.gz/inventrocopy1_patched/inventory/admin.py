"""
Django admin configuration for the inventory app.

This module registers the ``InventoryItem`` model with the Django admin
site and provides a basic list display for easy inspection and editing by
administrators. Additional configuration such as search fields or filters
can be added later as requirements evolve.
"""

from django.contrib import admin
from .models import InventoryItem


@admin.register(InventoryItem)
class InventoryItemAdmin(admin.ModelAdmin):
    list_display = ["name", "category", "quantity", "location", "updated_at"]
    search_fields = ["name", "location"]
    list_filter = ["category"]
