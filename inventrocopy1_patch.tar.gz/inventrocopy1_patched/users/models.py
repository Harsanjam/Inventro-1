"""
User management models for the Inventa project.

This module defines the user‑related data structures. A simple ``User``
model is provided alongside supporting ``UserType`` and ``Company`` models.
In order to support role‑based access control, the ``User`` model now
includes a ``role`` field with three possible values: ``ADMIN``,
``MANAGER`` and ``STAFF``. These roles correspond to the high‑level
permissions described in the project specification: administrators have
full access, managers can create and manage inventory entries, and staff
have restricted, read‑only access.
"""

from django.db import models


class UserType(models.Model):
    """Represents a user classification beyond built‑in roles.

    User types can be used to group users by profession or business
    function. This model is separate from the built‑in role system to
    provide additional flexibility for administrators. For example, an
    ``Employee`` user type could map to a ``STAFF`` role, while a
    ``Owner`` type might map to ``ADMIN``.
    """

    name = models.CharField(max_length=50)
    description = models.TextField(blank=True, null=True)

    def __str__(self) -> str:
        return self.name


class Company(models.Model):
    """Stores basic information about a company.

    Users can be associated with a company to support multi‑tenant setups.
    Additional fields (like phone number or email) can be added as needed.
    """

    name = models.CharField(max_length=100)
    address = models.CharField(max_length=150)

    def __str__(self) -> str:
        return self.name


class User(models.Model):
    """Custom user model for Inventa.

    The model stores minimal personal information about each user and
    references their company and type. A ``role`` field has been added to
    enforce role‑based access control throughout the application. See
    ``ROLE_CHOICES`` for valid values.
    """

    first_name = models.CharField(max_length=50)
    age = models.PositiveSmallIntegerField()
    address = models.CharField(max_length=150)
    company = models.ForeignKey(
        Company,
        on_delete=models.PROTECT,
    )
    type = models.ForeignKey(
        UserType,
        on_delete=models.PROTECT
    )

    # Role‑based access control
    ROLE_CHOICES = [
        ("ADMIN", "Admin"),
        ("MANAGER", "Manager"),
        ("STAFF", "Staff"),
    ]
    role = models.CharField(
        max_length=20,
        choices=ROLE_CHOICES,
        default="STAFF",
        help_text=(
            "Determines the user's permissions within the system. "
            "Admins have full access, managers can manage inventory, "
            "and staff have restricted access."
        ),
    )

    def __str__(self) -> str:
        return f"{self.first_name} ({self.get_role_display()})"
